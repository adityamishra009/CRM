import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import MainLayout from "./Pages/MainLayout";
import Dashboard from "./Pages/Dashboard";
import AllLeads from "./Pages/AllLeads";
import AllEmployees from "./Pages/AllEmployee";
import AllCustomers from "./Pages/AllCustomer";
import TaxInvoice from "./Pages/TaxInvoice";
import PublicRoute from "./Routes/PublicRoute";
import PrivateRoute from "./Routes/PrivateRoute";
import Login from "./Pages/Login";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function App() {
  const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";

  return (
    <BrowserRouter>

      <ToastContainer position="top-right" autoClose={2000} />

      <Routes>

        {/* ✅ ROOT DECISION */}
        <Route
          path="/"
          element={
            isLoggedIn ? (
              <Navigate to="/dashboard" />
            ) : (
              <Navigate to="/login" />
            )
          }
        />

        {/* ✅ LOGIN */}
        <Route
          path="/login"
          element={
            isLoggedIn ? <Navigate to="/dashboard" /> : <Login />
          }
        />

        {/* ✅ PRIVATE ROUTES */}
        <Route element={<PrivateRoute />}>
          <Route path="/" element={<MainLayout />}>
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="leads" element={<AllLeads />} />
            <Route path="employees" element={<AllEmployees />} />
            <Route path="customers" element={<AllCustomers />} />
            <Route path="invoice" element={<TaxInvoice />} />
          </Route>
        </Route>

        {/* ✅ fallback */}
        <Route path="*" element={<Navigate to="/" />} />

      </Routes>
    </BrowserRouter>
  );
}

export default App;